
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

void main() => runApp(OnlineStickersApp());

class OnlineStickersApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Online Stickers',
      theme: ThemeData(primarySwatch: Colors.green),
      home: StickerHomePage(),
    );
  }
}

class StickerHomePage extends StatelessWidget {
  final List<Map<String, String>> stickerPacks = [
    {
      'name': 'Funny Faces',
      'thumbnail': 'https://via.placeholder.com/150',
      'downloadUrl': 'https://example.com/download/funny_faces.zip'
    },
    {
      'name': 'Cute Animals',
      'thumbnail': 'https://via.placeholder.com/150',
      'downloadUrl': 'https://example.com/download/cute_animals.zip'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Online Stickers')),
      body: GridView.builder(
        padding: EdgeInsets.all(10),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.8,
        ),
        itemCount: stickerPacks.length,
        itemBuilder: (context, index) {
          final pack = stickerPacks[index];
          return Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Column(
              children: [
                Expanded(
                  child: CachedNetworkImage(
                    imageUrl: pack['thumbnail']!,
                    placeholder: (context, url) => Center(child: CircularProgressIndicator()),
                    errorWidget: (context, url, error) => Icon(Icons.error),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(pack['name']!, style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                ElevatedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Download started for ${pack['name']}')),
                    );
                  },
                  child: Text('Download'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
